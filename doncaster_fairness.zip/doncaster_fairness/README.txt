These results appear in the publication:

Reynolds, E., Ehrgott, M. and Wang, J.Y.T (2021) An evaluation of the fairness of railway timetable rescheduling in the presence of competition between train operators


The directory section_6 contains results from experiments described in Section 6.
 - toc_obj_summary.csv is indexed by instance. The columns correspond to operators via TOC codes. Values show the (unweighted) utility for each operator when an instance is solved to maximise efficiency.
   The codes are:
	    {'22':'GrandCentral', 
             '23':'Northern', 
             '61':'LNER', 
             '20':'Transpennine', 
             '27':'CrossCountry', 
             '55':'HullTrains', 
             '28':'East Midlands',
	     }
 - toc_obj_pairs_summary.csv is also has rows indexed by instance. The columns are pairs of operators, in the form X_Y, where X and Y are codes corresponding to operators, as shown above. Column X_Y shows the utility accrued by operator Y when trains operated by X are removed from the instance and the total efficiency of the remaining trains maximised.


The directory section_5_and_7 contains results that are used in Section 5 and 7. 
Subdirectories 0.4, 0.7 and 1.0 contain results obtained when w=0.4, 0.7 and 1.0 respectively.
Therefore the results in 0.4 are presented in Section 5, whilst Section 7 uses all of these results.
All the files in here are in the same format as those described elsewhere.
