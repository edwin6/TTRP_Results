Results from solving the TTRP using instances from Derby station.
Corresponds to the paper Reynolds, E. and Maher, S. J. (2021). A data-driven, variable-speed model for the train timetable rescheduling problem.

FS contains results for the fixed-speed model.
VS contains results for the variable-speed model.
numtrains.csv lists the number of trains in each instance.

Instances are named dat_000 ... dat_310, and appear in the index of datasets.


